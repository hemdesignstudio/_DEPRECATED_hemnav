"""Nav Module

This module handle all interactions with Microsoft Navision
"""
from .code_units import Inventory
from .pages import SalesOrder
